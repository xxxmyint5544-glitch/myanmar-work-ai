/* ai.js — a small rule-based Myanmar-language command parser.
   It is NOT a general LLM: it recognises the shapes of common shop
   commands (sales totals, stock lookups, adding credit, reports),
   pulls out numbers/names with regex, and calls the same DB helpers
   the other pages use. This keeps everything working fully offline. */

const MM_DIGITS = '၀၁၂၃၄၅၆၇၈၉';

function mmToArabicDigits(str) {
  return str.replace(/[၀-၉]/g, d => String(MM_DIGITS.indexOf(d)));
}

function extractAmount(text) {
  const norm = mmToArabicDigits(text).replace(/,/g, '');
  // support "5 သောင်း" (50,000) and "2 သိန်း" (200,000) shorthand
  let m = norm.match(/(\d+(?:\.\d+)?)\s*သိန်း/);
  if (m) return Math.round(parseFloat(m[1]) * 100000);
  m = norm.match(/(\d+(?:\.\d+)?)\s*သောင်း/);
  if (m) return Math.round(parseFloat(m[1]) * 10000);
  m = norm.match(/(\d{3,})/); // plain number, at least 3 digits to avoid grabbing stray small numbers
  if (m) return parseInt(m[1], 10);
  m = norm.match(/(\d+)/);
  if (m) return parseInt(m[1], 10);
  return null;
}

function extractPersonName(text) {
  // pattern: "<name>ကို" — the postposition ကို attaches directly to the
  // end of a name with no space (e.g. "မောင်အောင်ကို"), so split into
  // words and peel it off the token that ends with it.
  const tokens = text.split(/\s+/);
  for (const t of tokens) {
    if (t.length > 3 && t.endsWith('ကို')) {
      return t.slice(0, t.length - 3).trim();
    }
  }
  return null;
}

function extractItemQuery(text) {
  // strip common trailing question words to leave the item name
  return text
    .replace(/stock/gi, '')
    .replace(/ဘယ်လောက်ကျန်လဲ|ဘယ်လောက်ရှိလဲ|ကျန်လဲ|ရှိလဲ|ဘယ်နှစ်ခုလဲ|ဘယ်လောက်လဲ/g, '')
    .replace(/[?？]/g, '')
    .trim();
}

async function findItemByFuzzyName(query) {
  const items = await DB.getAll('inventory');
  const q = query.toLowerCase();
  if (!q) return null;
  let hit = items.find(i => i.name.toLowerCase() === q);
  if (hit) return hit;
  hit = items.find(i => i.name.toLowerCase().includes(q) || q.includes(i.name.toLowerCase()));
  return hit || null;
}

/* Look for a name the shop owner has ALREADY typed somewhere in the app
   (existing customers/suppliers in the credit list) inside free text.
   This is what lets the assistant recognise real names/items instead of
   only the two example names shown in the help text. */
async function findKnownPersonInText(text) {
  const rows = await DB.getAll('credits');
  const names = [...new Set(rows.map(r => r.person).filter(Boolean))];
  names.sort((a, b) => b.length - a.length); // longest match first
  return names.find(n => text.includes(n)) || null;
}

async function findKnownItemInText(text) {
  const items = await DB.getAll('inventory');
  const sorted = [...items].sort((a, b) => b.name.length - a.name.length);
  return sorted.find(i => text.includes(i.name)) || null;
}

/* ---------- intent handlers ---------- */

async function handleTodaySales() {
  const today = todayISO();
  const totals = await DB.salesTotalsByPayment(today, today);
  if (!totals.count) return `ယနေ့အတွက် ရောင်းအားမှတ်တမ်း <b>မရှိသေးပါ</b>။`;
  return `ယနေ့ (${Utils.todayLabel()}) ရောင်းအားစုစုပေါင်း <b>${Utils.kyat(totals.all)}</b> ဖြစ်ပါသည် — 💵 လက်ငင်း ${Utils.num(totals.cash)}, 🤝 အကြွေး ${Utils.num(totals.credit)} (စာရင်း ${totals.count} ခု)`;
}

async function handleTodayCash() {
  const today = todayISO();
  const totals = await DB.salesTotalsByPayment(today, today);
  return `ယနေ့ လက်ငင်းရောင်းအား <b>${Utils.kyat(totals.cash)}</b> ဖြစ်ပါသည်။`;
}

async function handleTodayCreditSales() {
  const today = todayISO();
  const totals = await DB.salesTotalsByPayment(today, today);
  return `ယနေ့ အကြွေးဖြင့် ရောင်းချသည့် ပမာဏ <b>${Utils.kyat(totals.credit)}</b> ဖြစ်ပါသည်။`;
}

async function handleExpenseQuery() {
  const today = todayISO();
  const rows = await DB.expensesBetween(today, today);
  const total = rows.reduce((s, e) => s + e.amount, 0);
  if (!rows.length) return `ယနေ့အတွက် အသုံးစရိတ် <b>မှတ်တမ်း မရှိသေးပါ</b>။`;
  const byCat = {};
  rows.forEach(e => { byCat[e.category] = (byCat[e.category]||0) + e.amount; });
  const lines = Object.entries(byCat).map(([c,v]) => `• ${Utils.escapeHtml(c)} — ${Utils.num(v)}`).join('<br>');
  return `ယနေ့ အသုံးစရိတ် စုစုပေါင်း <b>${Utils.kyat(total)}</b> —<br>${lines}`;
}

async function handleAddExpense(text) {
  const amount = extractAmount(text);
  if (!amount) return `ပမာဏကို ရှင်းရှင်းလင်းလင်း ပြောပြပါ။ ဥပမာ — "ကားခ ၅၀၀၀ ထည့်"`;
  const cats = await DB.expenseCategories();
  const found = cats.find(c => text.includes(c));
  const category = found || cats[cats.length - 1] || 'အခြား';
  await DB.addExpense({ category, amount, note: 'AI မှတဆင့် ထည့်သွင်းသည်' });
  return `<b>${Utils.escapeHtml(category)}</b> အသုံးစရိတ် <b>${Utils.kyat(amount)}</b> ထည့်သွင်းပြီးပါပြီ ✅`;
}

async function handleWeekSales() {
  const now = new Date();
  const d = new Date(now); d.setDate(d.getDate() - 6);
  const start = d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const sales = await DB.salesBetween(start, todayISO());
  const total = sales.reduce((s, r) => s + r.total, 0);
  return `လွန်ခဲ့သော ၇ ရက်အတွင်း ရောင်းအားစုစုပေါင်း <b>${Utils.kyat(total)}</b> ဖြစ်ပါသည်။`;
}

async function handleTodayProfit() {
  const today = todayISO();
  const sales = await DB.salesBetween(today, today);
  const totals = await DB.salesTotalsByPayment(today, today);
  const cost = sales.reduce((sum, sale) => sum + sale.items.reduce((s,l)=>s+(l.cost||0)*l.qty,0), 0);
  const expenses = await DB.expensesBetween(today, today);
  const expenseTotal = expenses.reduce((s,e)=>s+e.amount,0);
  const profit = totals.all - cost - expenseTotal;
  return `ယနေ့ ရောင်းအား <b>${Utils.kyat(totals.all)}</b>, ပစ္စည်းကုန်ကျစရိတ် ${Utils.num(cost)}, အသုံးစရိတ် ${Utils.num(expenseTotal)} နုတ်ပြီး — ယနေ့ <b>အသားတင်အမြတ် ${Utils.kyat(profit)}</b> ရပါသည်။`;
}

async function handleMonthProfit() {
  const now = new Date();
  const start = now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-01';
  const sales = await DB.salesBetween(start, todayISO());
  const total = sales.reduce((s, r) => s + r.total, 0);
  const cost = sales.reduce((sum, sale) => sum + sale.items.reduce((s,l)=>s+(l.cost||0)*l.qty,0), 0);
  const profit = total - cost;
  return `ဒီလအတွက် ရောင်းအား <b>${Utils.kyat(total)}</b>, ကုန်ကျစရိတ် ${Utils.num(cost)} ကျပ်, အသားတင်အမြတ် <b>${Utils.kyat(profit)}</b> ဖြစ်ပါသည်။ <br><a href="reports.html" style="color:var(--gold);">Full report ကြည့်ရန် →</a>`;
}

async function handleStockQuery(text) {
  const q = extractItemQuery(text);
  const item = await findItemByFuzzyName(q);
  if (!item) {
    const all = await DB.getAll('inventory');
    if (!all.length) return `ပစ္စည်းစာရင်းထဲမှာ ဘာမှ မထည့်ရသေးပါ။ <a href="inventory.html" style="color:var(--gold);">ပစ္စည်းအသစ် ထည့်ရန်</a>`;
    const sample = all.slice(0, 5).map(i => Utils.escapeHtml(i.name)).join('၊ ');
    return `"${Utils.escapeHtml(q)}" ဆိုတဲ့ ပစ္စည်းကို စာရင်းထဲမှာ ရှာမတွေ့ပါ။ လက်ရှိ စာရင်းထဲမှာ ရှိတာတွေက — ${sample} စသည်ဖြင့် ရှိပါသည်။ ပစ္စည်းအမည်ကို အတိအကျ ရေးကြည့်ပါ။`;
  }
  const low = (item.stock||0) <= (item.lowThreshold||0);
  return `<b>${Utils.escapeHtml(item.name)}</b> လက်ကျန် <b>${Utils.num(item.stock)} ${Utils.escapeHtml(item.unit||'')}</b> ကျန်ပါသည်။${low ? ' ⚠️ Stock နည်းနေပါပြီ။' : ''}`;
}

async function handleAddCredit(text) {
  // prefer a name the shop owner has already used before (recognises real
  // customers, not just the "မောင်အောင်" example), then fall back to
  // extracting a brand-new name from the "<name>ကို" pattern.
  let person = await findKnownPersonInText(text);
  if (!person) person = extractPersonName(text);
  const amount = extractAmount(text);
  if (!person || !amount) {
    return `နာမည်နှင့် ပမာဏကို ရှင်းရှင်းလင်းလင်း ပြောပြပါ — "<b>နာမည်</b>ကို <b>ပမာဏ</b> အကြွေးထည့်" ဆိုတဲ့ ပုံစံနဲ့ ရေးပါ (ဥပမာ — "ဒေါ်စန်းစန်းကို ၃၀,၀၀၀ အကြွေးထည့်")။ "ကို" ကို နာမည်နောက်မှာ မဖြစ်မနေ ထည့်ပါ။`;
  }
  const record = {
    id: DB.newId(),
    direction: 'receivable',
    type: 'customer',
    person,
    amount,
    paidAmount: 0,
    dueDate: '',
    note: 'AI မှတဆင့် ထည့်သွင်းသည်',
    status: 'ဆိုင်ရာ',
    history: [],
    createdAt: Date.now()
  };
  await DB.put('credits', record);
  return `<b>${Utils.escapeHtml(person)}</b> အတွက် အကြွေး <b>${Utils.kyat(amount)}</b> ထည့်သွင်းပြီးပါပြီ ✅ <br><a href="credit.html" style="color:var(--gold);">အကြွေးစာရင်း ကြည့်ရန် →</a>`;
}

async function handlePersonBalance(person) {
  const all = await DB.getAll('credits');
  const rows = all.filter(c => c.person === person && c.status !== 'ပြီးပြီ');
  if (!rows.length) return `<b>${Utils.escapeHtml(person)}</b> အတွက် ကျန်ငွေ စာရင်း မရှိပါ — အကုန်ပြေပြီး ဖြစ်နိုင်ပါသည် ✅`;
  const receivable = rows.filter(r => r.direction === 'receivable').reduce((s,r)=>s+(r.amount-(r.paidAmount||0)),0);
  const payable = rows.filter(r => r.direction === 'payable').reduce((s,r)=>s+(r.amount-(r.paidAmount||0)),0);
  const parts = [];
  if (receivable > 0) parts.push(`ကျွန်ုပ်တို့ ရရန် <b>${Utils.kyat(receivable)}</b>`);
  if (payable > 0) parts.push(`ကျွန်ုပ်တို့ ပေးရန် <b>${Utils.kyat(payable)}</b>`);
  return `<b>${Utils.escapeHtml(person)}</b> — ${parts.join('၊ ')} ကျန်ရှိပါသည်။`;
}

async function handleReceivableTotal() {
  const total = await DB.totalCreditOutstanding('receivable');
  return `လက်ရှိ ရရန်အကြွေး စုစုပေါင်း <b>${Utils.kyat(total)}</b> ကျန်ရှိပါသည်။`;
}

async function handlePayableTotal() {
  const total = await DB.totalCreditOutstanding('payable');
  return `လက်ရှိ ပေးရန်အကြွေး စုစုပေါင်း <b>${Utils.kyat(total)}</b> ကျန်ရှိပါသည်။`;
}

async function handleLowStock() {
  const low = await DB.lowStockItems();
  if (!low.length) return `Stock နည်းနေသော ပစ္စည်း <b>မရှိပါ</b> — အားလုံး လုံလောက်ပါသည် ✅`;
  const list = low.slice(0,6).map(i => `• ${Utils.escapeHtml(i.name)} (${Utils.num(i.stock)} ${Utils.escapeHtml(i.unit||'')})`).join('<br>');
  return `Stock နည်းနေသော ပစ္စည်း ${low.length} မျိုး —<br>${list}`;
}

/* ---------- router ---------- */

async function routeCommand(raw) {
  const text = raw.trim();
  const lower = text;

  // credit / expense additions must be checked before the generic sales-total rules
  if (/အကြွေးထည့်|အကြွေးတင်|ကြွေးထည့်/.test(lower)) return handleAddCredit(text);
  if (/(ကားခ|သုံးစရိတ်|ဆိုင်ခ|လျှပ်စစ်ခ)\s*.*ထည့်/.test(lower)) return handleAddExpense(text);

  if (/ဒီနေ့/.test(lower) && /လက်ငင်း/.test(lower)) return handleTodayCash();
  if (/ဒီနေ့/.test(lower) && /အကြွေး/.test(lower) && /ရောင်း/.test(lower)) return handleTodayCreditSales();

  // profit / earnings — shop owners phrase this many different ways
  // ("အမြတ်", "ကောင်းရငွေ", "ငွေရ", "profit"...), so match on a broad set
  // of synonyms and scope by whichever time-word ("ဒီနေ့/ဒီအပတ်/ဒီလ") appears.
  const profitWord = /အမြတ်|ကောင်းရ|ကောင်းငွေ|profit|အသားတင်/.test(lower);
  if (profitWord && /ဒီလ/.test(lower)) return handleMonthProfit();
  if (profitWord && (/ဒီအပတ်|၇ ?ရက်/.test(lower))) return handleWeekSales();
  if (profitWord) return handleTodayProfit();

  if (/ဒီနေ့/.test(lower) && /ရောင်းအား|အရောင်း/.test(lower)) return handleTodaySales();
  if (/ဒီအပတ်|၇ ?ရက်/.test(lower) && /ရောင်းအား|အရောင်း/.test(lower)) return handleWeekSales();
  if (/ဒီလ/.test(lower) && /ရောင်းအား/.test(lower)) return handleMonthProfit();

  if (/အသုံးစရိတ်|ကားခ/.test(lower) && /ဘယ်လောက်|ဘယ်နှစ်|report|ပြ/.test(lower)) return handleExpenseQuery();

  if (/ရရန်.*အကြွေး|အကြွေး.*ရရန်/.test(lower)) return handleReceivableTotal();
  if (/ပေးရန်.*အကြွေး|အကြွေး.*ပေးရန်/.test(lower)) return handlePayableTotal();

  if (/stock ?နည်း|ကုန်တော့|ကုန်နီးပြီ/.test(lower)) return handleLowStock();

  // ambiguous "ဘယ်လောက်ကျန်လဲ / ရှိလဲ" — could be asking about a customer's
  // outstanding balance OR an item's stock. Check against real data the shop
  // owner has already entered before falling back to a generic stock search.
  if (/ကျန်လဲ|ရှိလဲ|လက်ကျန်|stock/.test(lower)) {
    const knownPerson = await findKnownPersonInText(lower);
    if (knownPerson) return handlePersonBalance(knownPerson);
    const knownItem = await findKnownItemInText(lower);
    if (knownItem) return handleStockQuery(knownItem.name);
    return handleStockQuery(text);
  }

  if (/မင်္ဂလာပါ|ဟယ်လို|hello|hi\b/i.test(lower)) {
    return `မင်္ဂလာပါ! ကျွန်တော် ကူညီပေးနိုင်တာတွေက — ယနေ့/အပတ်စဉ် ရောင်းအားတွက်ခြင်း (လက်ငင်း/အကြွေး ခွဲပြနိုင်)၊ ပစ္စည်း stock စစ်ခြင်း၊ အကြွေးထည့်ခြင်း၊ အသုံးစရိတ်မှတ်ခြင်း၊ အမြတ် report ကြည့်ခြင်း တို့ပါ။ အောက်က ဥပမာလေးတွေကို နှိပ်ကြည့်နိုင်ပါတယ်။`;
  }

  // last resort — show what it actually knows (real items/customers) instead
  // of only repeating the two canned example names.
  const items = await DB.getAll('inventory');
  const credits = await DB.getAll('credits');
  const itemHint = items.length ? `ပစ္စည်း — ${items.slice(0,3).map(i=>Utils.escapeHtml(i.name)).join('၊ ')}` : '';
  const personHint = credits.length ? `Customer — ${[...new Set(credits.map(c=>c.person))].slice(0,3).map(Utils.escapeHtml).join('၊ ')}` : '';
  const knownHint = [itemHint, personHint].filter(Boolean).join(' / ');
  return `ဒီစာကို ရှင်းရှင်းလင်းလင်း နားမလည်သေးပါ 🙏 ပုံစံ — "&lt;နာမည်&gt;ကို &lt;ပမာဏ&gt; အကြွေးထည့်" ဒါမှမဟုတ် "&lt;ပစ္စည်းအမည်&gt; stock ဘယ်လောက်ကျန်လဲ" လို့ ရေးကြည့်ပါ။${knownHint ? `<br><span class="small muted">လက်ရှိ သိထားတာ — ${knownHint}</span>` : ''}`;
}

/* ---------- chat UI ---------- */

function appendBubble(text, who) {
  const wrap = document.getElementById('chatWrap');
  const div = document.createElement('div');
  div.className = 'bubble ' + who;
  div.innerHTML = text;
  wrap.appendChild(div);
  wrap.scrollIntoView({ block: 'end' });
  window.scrollTo(0, document.body.scrollHeight);
}

async function sendMessage(text) {
  if (!text || !text.trim()) return;
  appendBubble(Utils.escapeHtml(text), 'user');
  document.getElementById('chatInput').value = '';
  const thinkingId = 'thinking-' + Date.now();
  appendBubble(`<span id="${thinkingId}">…</span>`, 'ai');
  const reply = await routeCommand(text);
  const el = document.getElementById(thinkingId);
  if (el) el.parentElement.innerHTML = reply;
}

/* ---------- voice input (Web Speech API, best-effort) ---------- */

function setupVoice() {
  const micBtn = document.getElementById('micBtn');
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    micBtn.addEventListener('click', () => Utils.toast('ဒီ browser မှာ အသံဖြင့်ရေးခြင်း Support မလုပ်ပါ'));
    return;
  }
  const rec = new SR();
  rec.lang = 'my-MM';
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  let listening = false;

  micBtn.addEventListener('click', () => {
    if (listening) { rec.stop(); return; }
    try {
      rec.start();
      listening = true;
      micBtn.classList.add('listening');
    } catch (e) {}
  });

  rec.onresult = (e) => {
    const said = e.results[0][0].transcript;
    document.getElementById('chatInput').value = said;
    sendMessage(said);
  };
  rec.onend = () => { listening = false; micBtn.classList.remove('listening'); };
  rec.onerror = () => { listening = false; micBtn.classList.remove('listening'); Utils.toast('အသံ မမှတ်နိုင်ပါ — ထပ်စမ်းကြည့်ပါ'); };
}

document.addEventListener('DOMContentLoaded', () => {
  Utils.mountChrome('AI လုပ်ငန်းကူ', 'ai.html');

  document.getElementById('sendBtn').addEventListener('click', () => sendMessage(document.getElementById('chatInput').value));
  document.getElementById('chatInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') sendMessage(e.target.value);
  });
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => sendMessage(chip.textContent));
  });

  setupVoice();

  // if the dashboard's quick-ask box sent us here with a pending query
  const pending = sessionStorage.getItem('pendingAiQuery');
  if (pending) {
    sessionStorage.removeItem('pendingAiQuery');
    sendMessage(pending);
  }
});
